package com.ksb.openapi.mobile.entity;

public class Bean {

}
